from db import *

db_file = "verysecuredatabase.db"

if __name__ == '__main__':
    create_and_populate_db(db_file)
